create
    definer = root@localhost procedure DeleteVideo(IN idDel int)
begin
    delete  from video where  id =idDel;
end;

