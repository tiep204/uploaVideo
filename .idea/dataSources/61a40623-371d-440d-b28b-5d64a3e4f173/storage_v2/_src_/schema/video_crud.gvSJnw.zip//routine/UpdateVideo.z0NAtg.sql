create
    definer = root@localhost procedure UpdateVideo(IN idUp int, IN url text, IN til varchar(100), IN des text)
begin
    UPDATE  video set  video_url = url,title=til,description=des where id=idUp;
end;

