create
    definer = root@localhost procedure FindById(IN idFind int)
begin
    SELECT  * from video  where  id = idFind;
end;

