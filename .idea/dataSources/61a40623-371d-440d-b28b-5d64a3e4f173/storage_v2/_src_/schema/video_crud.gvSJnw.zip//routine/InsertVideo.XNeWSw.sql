create
    definer = root@localhost procedure InsertVideo(IN url text, IN til varchar(100), IN des text)
begin
    INSERT INTO Video(video_url, title, description)  value (url,til,des);
end;

