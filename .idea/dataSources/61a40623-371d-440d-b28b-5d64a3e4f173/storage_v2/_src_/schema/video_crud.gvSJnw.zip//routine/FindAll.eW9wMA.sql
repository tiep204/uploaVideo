create
    definer = root@localhost procedure FindAll()
begin
    SELECT  * from video;
end;

